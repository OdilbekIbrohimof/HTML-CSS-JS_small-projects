// let text  = document.querySelector('.text');
// let buton = document.querySelectorAll('button');
// let img = document.querySelector('.img');

// console.log(buton);

// buton.forEach((item, i)=> {
//     console.log(item, i);
// })

// buton.addEventListener('click', () =>{
//     text.classList.toggle('active');
//     img.classList.toggle('active');
//     console.log('clikc');
// })


function showTime() {
    let data = new Date();
    let ildiz = data.toTimeString().split(" ")[0];
    document.querySelector('.hour').textContent = ildiz;

    }

showTime();
setInterval(() => {
    showTime();
}, 1000);


function timeShow() {
    let s = new Date();
    let yil = s.getFullYear();
    document.querySelector('.yillar').textContent = yil;

}
timeShow();

function timeShoow() {
    let d = new Date();
    let oy = d.getMonth();
    document.querySelector('.oy').textContent = oy;
}
timeShoow();
function timeDay() {
    let c = new Date();
    let kun = c.getDate();
    document.querySelector('.kun').textContent = kun;
    console.log(d);
}
timeDay();
   
//     let oylar = ["yan", "fev", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentyabr", "ocktyabr", "noyabr", "dekabr"]
//  let d = oylar;

// console.log(yil+"-yil");


// setInterval(() => {
//     console.log('salom');
//     document.write(' hello ')
// }, 1000);

// setTimeout(() => {
//     alert('salom ')
// }, 200);